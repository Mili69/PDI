



-- 29-09-22

-- Mostrar los empleados cuyo nombre empiece entre las letras J y Z (rango).Liste estos empleados y su cargo por orden alfabético.

select nomEmp,cargoE from departamentos.empleados where (nomEmp) > 'J' and (nomEmp) < 'Z' order by (nomEmp) asc;

-- 2. Listar el salario, la comisión, el salario total (salario + comisión), documento de identidad del empleado y nombre, de aquellos empleados que tienen comisión superior a 1.000.000, ordenar el informe por el número del DNI.

select salEmp, comisionE, (salEmp+comisionE) as 'total' , nDIEmp, nomEmp from empleados where comisionE > 1000000 order by nomEmp asc;

-- 3. Obtener un listado similar al anterior, pero de aquellos empleados que NO tienen comisión
select  salEmp, cargoE, nDIEmp, nomEmp from empleados where lower (nomEmp) not like (comisionE) order by nomEmp asc;

-- 4. Hallar los empleados cuyo nombre no contiene la cadena "MA"
select nomEmp,cargoE from departamentos.empleados where lower(nomEmp) NOT LIKE '%ma%';

-- 5. Obtener los nombres de los departamentos que no sean “Ventas” ni “Investigación” NI 'MANTENIMIENTO'.
select nombreDpto from departamentos.departamentos where lower(nombreDpto) not in ('mantenimiento', 'ventas', 'investigación');

