<?php

<?php
$conn = new mysqli("localhost","root","","miempresa");

//recibimos el id por url
$id_empleado = $_GET['id'];

//buscamos el empleado con el legado recibido
$buscar = "SELECT * FROM empleados WHERE legajo = '$id_empleado'";

//ejecutamos la consulta
$query = mysqli_query($conn,$buscar);

//recorremos los resultados y cargamos el form
foreach($query as $res){




}
?>


