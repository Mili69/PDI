<?php
$conn = new mysqli("localhost","root","","integradora2");
$buscar = $_POST['buscar'];



//consulta para hacer la busqueda de empleados
$buscar = "SELECT empleados.apellido_nombre, puestos.puesto, puestos.sueldo FROM empleados, puestos WHERE empleados.puesto = puestos.id AND empleados.apellido_nombre LIKE'%buscar%'";

//ejecutamos la busqueda
$query = mysqli_query($conn,$buscar);

//foreach recorre todos los resultados obtenidos
foreach($query as $res){
    echo("<br>Legajo:". $res['legajo']);
    echo("<br>Apellido y Nombres:". $res['apellido_nombre']);
    echo("<br>Puesto: ".$res['verPuesto']);
    echo("<br>Sueldo: $ ". $res['sueldo']);
    echo("<br>Fecha de ingreso. ".$res['fecha_ingreso']);
    echo("<br><a href='modificar.php'>Modificar</a>");
    echo(" <a href='eliminar.php'>Eliminar</a>");
    echo("<hr>");

}
?>

